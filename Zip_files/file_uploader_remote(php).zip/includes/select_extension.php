<?php
$include_page="upload.php";
$selected_ext=strtolower($selected_ext);

if($selected_ext=='png') { include $include_page; }
elseif($selected_ext=='jpg') { include $include_page; }
elseif($selected_ext=='mp3') { include $include_page; }
elseif($selected_ext=='mp4') { include $include_page; }
elseif($selected_ext=='svg') { include $include_page; }
elseif($selected_ext=='wav') { include $include_page; }
elseif($selected_ext=='html') { include $include_page; }
elseif($selected_ext=='java') { include $include_page; }
elseif($selected_ext=='js') { include $include_page; }elseif($selected_ext=='json') { include $include_page; }
elseif($selected_ext=='txt') { include $include_page; }
elseif($selected_ext=='phtml') { include $include_page; }


else{ echo "Sorry you can't upload " .$selected_ext." files"; }


?>