<?php

$base64_string=  @file_get_contents('php://input');

if(!empty($base64_string)) { 

include "includes/base64_to_file.php";  
include "includes/submit_file.php";
} else { echo "data can't be empty"; }

?>