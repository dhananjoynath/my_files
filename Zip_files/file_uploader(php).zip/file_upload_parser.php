<?php
//$mobile_site='false';
$mobile_site='true';
include "../../connection.php";
include "../../includes/functions.php"; 
include "../../header_files.php"; 
?>

 <?php
print_r($_FILES);


if(isset($_FILES["file1"])) {$file_set="true"; }
        
$fileName = $_FILES["file1"]["name"]; 
$fileTmpLoc = $_FILES["file1"]["tmp_name"]; 
$fileType = $_FILES["file1"]["type"];
$fileSize = $_FILES["file1"]["size"]; 
$fileErrorMsg = $_FILES["file1"]["error"]; 



$folder ="files";
$ext = pathinfo($fileName, PATHINFO_EXTENSION);
$create_folder=$folder."/".$ext;
echo $location="files/5665.mp4";


$data=file_get_contents($_FILES["file1"]);

echo  base64_to_file($data, $location, $is_decoded); 
 


if(!file_exists($create_folder)){
mkdir($create_folder);
}


?>





