<?php
if(isset($_FILES["anyfile"]) && $_FILES["anyfile"]["error"] == 0){ echo 'ok'; }else{ echo 'ohhh'; }



if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(isset($_FILES["anyfile"]) && $_FILES["anyfile"]["error"] == 0){
    	echo "<pre>";
    	print_r($_FILES["anyfile"]);
    	echo "</pre>";
    	
    	
    	
        $allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png", "cr2" => "image/cr2");

        $filename = $_FILES["anyfile"]["name"];
        $filetype = $_FILES["anyfile"]["type"];
        $filesize = $_FILES["anyfile"]["size"];
        $folder ="files";
        
        
      //  $file_destination=$folder.'/'.$filename;
        

        $ext = pathinfo($filename, PATHINFO_EXTENSION);

        if(!array_key_exists($ext, $allowed)) die("Error: Please select a valid file format.");


        $maxsize = 10 * 1024 * 1024;

        if($filesize > $maxsize) die("Error: File size is larger than the allowed limit.");
        
        if(in_array($filetype, $allowed)){
        
            if(file_exists($folder."/".$filename)){
                echo $filename . " is already exists.";  }
                
                 else{

                if(move_uploaded_file($_FILES["anyfile"]["tmp_name"], $folder."/".$filename)){ // if move_uploaded
                    echo "Your file was uploaded successfully."; 
                    echo '<a href="'.$folder."/".$filename.'"> See it </a>';   } 
                    // if move_uploaded end 
                    else{ echo "Sorry!! File is not uploaded"; }
            } 

        } else{
            echo "Error: There was a problem uploading your file.";  }
            
            
            
    } else{ echo "Error: " . $_FILES["anyfile"]["error"];   }
    
    
    
    
    
    
}

?>