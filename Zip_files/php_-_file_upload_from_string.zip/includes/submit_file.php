<?php
 $base64_string= @file_get_contents('php://input');
 
 
 /* response:-
  filename=filename.php&data=some_data
  */

$data = urldecode($base64_string);
 $data = explode("&data=", $data);
 $file_name= $data['0']; 
 
 
 $file_name = explode("filename=", $file_name);
 $file_name=$file_name['1'];
 
 $create_folder ="files";
 
 if(!file_exists($create_folder)){  mkdir($create_folder); }


  $file_name = str_replace(' ', '_', $file_name); 
  $filedata= $data['1']; 
  $file_destination=$create_folder."/".$file_name;
  $is_decoded="f";


?>





<?php
if(isset($data) && !empty($data) ) {
$result=  base64_to_file($filedata, $file_destination, $is_decoded );


if($result=='true') {
   $response= $_SERVER["REQUEST_SCHEME"].'://'.$_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'].''.$file_destination; 
      
    $fileInfo = pathinfo($response);
    $filename= $fileInfo['basename'];
    
  
echo  '[{ "status" : "success",  "file_name" :  "'.$filename.'" ,"file_path" : "'.$response.'"  }]';

}


} else { echo  '[{ "status" : "failed",  "file_name" :  "'.$filename.'"}]';   }

?>