  <?php    
 
 $folder="testfile";
 
if(!file_exists($folder)){ mkdir($folder); }
 
 
    
   /* $data = @file_get_contents('php://input'); */
   
   
    $data = "test file" ;
    
    
    $rand=rand();
    $rand="dj";
    
    $fp = fopen($folder."/test.json", "wb");

    fwrite($fp, $data);
    fclose($fp);
  
 
    
?>