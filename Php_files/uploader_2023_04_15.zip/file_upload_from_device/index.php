<!DOCTYPE html>
 <html>
 <head>
	 <title> Welcome to Dhananjoy Nath</title>
	 <meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	 <link rel="stylesheet" href="" type="text/css"/>
 </head>
	 <body>
	

	<form action="upload.php" method="post" enctype="multipart/form-data">

	    <h2>PHP Upload File</h2>

	    <label for="file_name">Filename:</label>

	    <input type="file" name="anyfile" id="anyfile" required>

	    <input type="submit" name="submit" value="Upload">

	    <p><strong>Note:</strong> Only .jpg, .jpeg, .gif, .png formats allowed to a max size of 5 MB.</p>

	</form>
	
	

</body>

</html>