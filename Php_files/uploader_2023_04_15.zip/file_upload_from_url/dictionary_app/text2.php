 
<?php
$file='dictionary.txt';
$data= @file_get_contents($file);

$str =$data;  
  


$arr=str_word_count($str, 1);

$file='dictionary2.txt';
$myfile = fopen($file, "w") or die("Unable to open file!");

$txt=$data;
fwrite($myfile, $txt);

fwrite($myfile, $txt);
fclose($myfile);

 
?>


<?php


include '../connection.php';
include "../includes/private_functions.php"; 

//print_r ($all_words);
$l=0;
foreach($arr as $all_words) {
$l=$l+1;

 $all_words=strtolower($all_words);

}


//print_r($arr);

 $count= count($arr,1);
echo $countt='total: ' .$count;

 echo '<br>';

echo '<br>';

$ccc=explode(".",$count/10000);

echo $ccc=$ccc[0];


 echo '<br>';
//echo $count= ceil($count/1000);
echo '<br>';





?>



<?php  


$r=0;
for ($x = 1; $x <= $ccc; $x++) {

$c= $x*10000-10000+1;
$r=$x*10000;

 // echo "Page: " .$x.") ". $xx ." "   .$c. " - "   .$r. " <br>";
  
}
?>  



<?php  


$sl=0;


$x_from=1;

$x_to=10000;

$json_array='';
for ($x_from; $x_from <= $x_to; $x_from++) {


$x=$x_from;



$sl=$sl+1;



//echo '<p>' . $sl.') ' . $arr[$x] .'</p>';

//echo $w= '{word="' .$arr[$x] .'"}';




if($x!=$x_to) {  $json_array.= '{ id='.$x. ', word="' .strtolower($arr[$x]) .'"} , '; 
} else {  $json_array.= '{ id='.$x. ', word="' .strtolower($arr[$x]) .'"}';  }


}



echo '['.$json_array.']';
?>  




