<!DOCTYPE html>
 <html>
 <head>
 
<?php
//$mobile_site='false';
$mobile_site='true';
include "../../connection.php";
include "../../includes/functions.php"; 
include "../../header_files.php"; 
?>
	 <title> Welcome to Techno Pencil</title>
	 <meta charset="UTF-8"/>
	 <link rel="stylesheet" href="" type="text/css"/>
 </head>
	 <body>


<style>

.div1{margin:  height: 10px;  width: 340px; background: red; }
.div2{ position: absolute; z-index: 2; left: 0; height: 5px; width: 1%; background: blue; }
#detailsr{ color: red; }

#file_name{ color: brown;}

</style>


<br>
<p class="hide"> 

accept="file_extension|audio/*
<br |video/*|image/*|media_type" onchange="uploadFile()"
</p>
 
 <p id="h1"> Upload ur files </p>
<form id="upload_form" enctype="multipart/form-data">
<p>   <input type="file" id="file1" onchange="uploadFile()"></form></p>
<p>
 <button class="hide" id="confirm_upload" onclick="malert()"> Confirm upload </button> 
</p>


<p id="max_size"></p>
  <p id="status"></p>
  <p id="details"></p>
  <p id="loaded_n_total"></p>
</form>
 

<div id="preview"></div>
<p>
<audio id="audio_player"  controls>
  <source src="" type="audio/ogg">
  
 
</audio>
</p>

<script>
function _(el) {
  return document.getElementById(el);
}


function cuploadFile() {
  var file = _("file1").files[0];
  var formdata = new FormData();
  formdata.append("file1", file);
  
  
  var ajax = new XMLHttpRequest();
 ajax.upload.addEventListener("progress", progressHandler, false);
ajax.addEventListener("load", completeHandler, false);
  ajax.addEventListener("error", errorHandler, false);
  ajax.addEventListener("abort", abortHandler, false);
  
 
  ajax.open("POST", "file_upload_parser.php"); 
 ajax.send(formdata);
 
}

function uploadFile() {
_("confirm_upload").style.display='block'; 

  var file = _("file1").files[0];
  var filesize=file.size;
  var  filesize_inMB=filesize/1000000;
  var  filesize_inKB=filesize/1000;
  var tofix=parseFloat(filesize_inMB).toFixed(2);
  
  
  if(tofix>1){ 
  
  var s=parseFloat(filesize_inMB).toFixed(2);
  var extension='MB';
  
  } else { var s=parseFloat(filesize_inKB).toFixed(2);
  var s=Math.ceil(s);
  var extension='KB';
  
   }


    _("max_size").innerHTML=s+' ' + extension;
    
    
    
   
      _('details').innerHTML='<b>' + file.name+'</b> <br>File Size: '+s+' ' +extension + ' | File type: '+file.type;
      
      
    
  var formdata = new FormData();
  formdata.append("file2", file);
  var ajax = new XMLHttpRequest();
 ajax.upload.addEventListener("progress", progressHandler, false);
ajax.addEventListener("load", completeHandler, false);
  ajax.addEventListener("error", errorHandler, false);
  ajax.addEventListener("abort", abortHandler, false);
  ajax.open("POST", "file_upload_parser.php"); 
ajax.send(formdata);
 
}






function progressHandler(event) {
  var file = _("file1").files[0];
   blob_url=URL.createObjectURL(file);
   
   
     _("audio_player").src=blob_url;
     
     
     
     

var event_loaded=event.loaded/1000000;
var event_total=event.total/1000000;

var event_total = parseFloat(event_total).toFixed(2);
var event_loaded = parseFloat(event_loaded).toFixed(2);


  _("loaded_n_total").innerHTML = "Loaded " + event_loaded + " MB of " + event_total + " MB";
  var percent = (event.loaded / event.total) * 100;

  _("status").innerHTML = Math.round(percent) + "% uploaded... please wait";
}

function completeHandler(event) {
  _("status").innerHTML = event.target.responseText;

}

function errorHandler(event) {
  _("status").innerHTML = "Upload Failed";
}

function abortHandler(event) {
  _("status").innerHTML = "Upload Aborted";
}

</script>



<script>



</script>

</body>
</html>