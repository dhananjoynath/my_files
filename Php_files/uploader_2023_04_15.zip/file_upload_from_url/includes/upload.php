
<style>
body a { color: red; }
</style>

<?php
if(isset($file_url)) {
$create_folder=$global_destination_folder."/".$selected_ext;
if(!file_exists($create_folder)){
mkdir($create_folder);
}

$pathinfo = pathinfo($file_url);
 $file_name_from_url=$pathinfo['filename'];
     
        date_default_timezone_set("Asia/Calcutta");
         $date =date("dmY_-_hi");

     $filename=$file_name_from_url."_".$date.".".$selected_ext;
     
     $file_final_destination=$global_destination_folder."/".$selected_ext."/".$filename;
      $file_content = @file_get_contents($file_url);
     
    
    
      $fopen = fopen($file_final_destination, "w");
      
      $fwrite = fwrite($fopen, $file_content);
      fclose($fopen);
      if ($fwrite) { echo '<center>' .$selected_ext. " file uploaded successfully</center>"; 
      
      echo '<p><a href="files/'.$selected_ext.'">'.$filename .'</a></p>';
       }  
      else { echo   "<center>Sorry!! " .$selected_ext. "file not upload. please try again</center>";   
      unlink($file_final_destination); }
      }
      
      
 ?>
      
   