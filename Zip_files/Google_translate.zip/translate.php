 <?php
            require_once "vendor/autoload.php";
            use \Statickidz\GoogleTranslate;
           
            
?>
            
            
   <?php

      if(isset($_GET['tl']) && isset($_GET['sl']) 
      && isset($_GET['text']) && ! empty($_GET['tl'])
       && ! empty($_GET['sl'])   && ! empty($_GET['text'])) {
            
            $text=$_GET['text'];
            $source = $_GET['sl']; // source language
            $target = $_GET['tl']; // target language



            
          
            $trans = new GoogleTranslate();
            $result = $trans->translate($source, $target, $text);

           
           
           } else { echo "sorry"; }

        ?>
        
        
        <?php

        $text= "How are you? I am your best friend. Do you have a bf?";
          $source = "en";
          $target= "bn";
          
            $trans = new GoogleTranslate();
             $result = $trans->translate($source, $target, $text);
            echo $result;
            
           ?>