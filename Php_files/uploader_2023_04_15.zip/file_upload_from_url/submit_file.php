<?php
         $global_destination_folder= "files";                    
         if(!file_exists($global_destination_folder)){
                 mkdir($global_destination_folder);  }
                                 


if(isset($_GET["file_url"])) {  $file_url = $_GET["file_url"];
  if (filter_var($file_url, FILTER_VALIDATE_URL)) {
  
  
    $pathinfo = pathinfo($file_url);
    if (isset($pathinfo["extension"])) { // if isset extension started
                                 $global_destination_folder= "files";                    
                                 if(!file_exists($global_destination_folder)){
                                 mkdir($global_destination_folder);  }
                                 $file_path=parse_url($file_url)['path']; 
                                $pathinfo =pathinfo($file_path);
                                 $selected_ext=$pathinfo['extension'];  
                                 include "includes/select_extension.php";
    } // if isset extension ended
     else { echo  "File extension not available .
      You cant upload this.....";
      
 
      $selected_ext='phtml';  
       include "includes/select_extension.php";
      
        } }
     
     
      else { echo  "Please enter a valid URL."; }
}

?>