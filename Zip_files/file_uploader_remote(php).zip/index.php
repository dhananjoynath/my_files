<!DOCTYPE html>
<head>
<title> Remote file uploader </title>
 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<style>
p {margin-left: 10px;
margin-right: 10px;
}
.p::first-letter {
  font-size: 20px;
}

input[type=text], input[type=password] , input[type=email] , input[type=number]{
caret-color: red;
background: none;
    width: 100%;
    padding: 5px;
    border-radius: 10px;
    border:1px solid purple;
    -webkit-box-sizing: border-box; /* Safari/Chrome, other WebKit */
    -moz-box-sizing: border-box;    /* Firefox, other Gecko */
    box-sizing: border-box;         /* Opera/IE 8+ */
}



#contact{color:white;
font-family: serif;
text-align: center;
background: #262833;
        border: none;
        border-radius: 5px;
        padding-top: 5px; 
        padding-bottom: 5px; 
}


::-webkit-input-placeholder { /* Edge */
  color: brown;
  
  font-family: Hind Siliguri, Poppins;
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
  color: brown;
  font-family:  Hind Siliguri, Poppins;
}

::placeholder {
  color: pink;
  font-family: Hind Siliguri, Poppins;
}

button, input[type=submit] {
width: 100%; 
color:white;
font-family:  Hind Siliguri, Poppins;
font-weight: bold;

    padding: 5px;

        background: black;
        border: none;
        border-radius: 5px;
}


  textarea {
  background: none;
  border-radius: 5px;
  border:1px solid purple;
  
  color: black;
  width: 99%;
  height: 100px;
}

::selection { background: pink;
color: brown; }
.text {color: blue; }
</style>


</head>
<body>

<p id="contact"> Remote file uploader </p>

<form action="submit_file.php" method="get">
<p>
<input type="text"  name="file_url" autocomplete="off" value="" placeholder="Paste your file link here......">
</p>
<p>
<button type="submit"> Upload </button>

</p>
 

</form>

</body>
</html>