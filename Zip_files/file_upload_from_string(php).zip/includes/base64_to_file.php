 <?php 
  function base64_to_file($base64_string, $file_destination, $is_decoded ) { 
  /*$input_file = str_replace('data:audio/mpeg;base64,', '', $input_file); */
  
  
  if($is_decoded=='t') { }
  elseif($is_decoded=='f'){$base64_string= base64_decode($base64_string);
  }
  
   $this_file_name = basename($file_destination); 
  $extension = pathinfo($file_destination, PATHINFO_EXTENSION);

   $ifp = fopen($file_destination, "wb" ); 
   $file_size= fwrite($ifp, $base64_string); 
    
   if($file_size>0) {  return 'true'; 
  
   
$php_arrays= 
array(  'link' => $file_destination,  'size' => $file_size,  'size_unit' => 'b',    'name' =>$this_file_name, 'file_extention'=>   $extension);
//return $json_arrays= json_encode($php_arrays);
   }
    
    else{ unlink($file_destination);  
     $file_destination. " couldn't uploaded";   }
    fclose ($ifp); 

}

?>
