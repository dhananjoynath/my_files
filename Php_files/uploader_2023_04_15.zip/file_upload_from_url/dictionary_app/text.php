<?php
 
$data= @file_get_contents('http://localhost:8000/file_uploader_remote/files/txt/dictionary_100k.txt');




?>

<?php
//$my_str = 'If the facts do not fit the theory, change the facts.';

$r='#!comment: 1 - 100';
 
// Display replaced string
 $data= str_replace($r, " ", $data);

$r='#!comment:';

$data= str_replace($r, " ", $data);

$r='This is a list of the top 100,000 most frequently-used English words';


echo '<pre>';
  $data=str_replace($r, " ", $data);
 echo '</pre>';
 
 
 $r='-';
 echo '<pre>';
  $data= str_replace($r, " ", $data);
 echo '</pre>';
 
 
 
 $r="'";
 $data= str_replace($r, " ", $data);
 ?>
 
 
 
<?php
$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");

$txt=$data;
fwrite($myfile, $txt);



fwrite($myfile, $txt);
fclose($myfile);
?>


<?php


 $data= @file_get_contents('newfile.txt');

function remove_numbers($string) {
   return preg_replace('/[0-9]+/', null, $string);
}

$data= remove_numbers($data);

?>

 
<?php

$file='dictionary.txt';
$myfile = fopen($file, "w") or die("Unable to open file!");

$txt=$data;
fwrite($myfile, $txt);

fwrite($myfile, $txt);
fclose($myfile);

 $data= @file_get_contents($file);

//echo strlen($data);
?>


<?php


include '../connection.php';
include "../includes/private_functions.php"; 



$str =$data;  
  
//echo '<pre>';




$arr=str_word_count($str, 1);

//print_r($arr);

 $count= count($arr,1);
echo $countt='total: ' .$count;

 echo '<br>';

echo '<br>';

$ccc=explode(".",$count/1000);

echo $ccc=$ccc[0];


 echo '<br>';
//echo $count= ceil($count/1000);
echo '<br>';





?>



<?php  


$r=0;
for ($x = 1; $x <= $ccc; $x++) {

$c= $x*1000-1000+1;
$r=$x*1000;

//  echo "Page: ". $xx ." "   .$c. " - "   .$r. " <br>";
  
}
?>  



<?php  


$sl=0;
for ($x = 1; $x <= 1000; $x++) {



$sl=$sl+1;
echo '<p>' . $sl.') ' . $arr[$x] .'</p>';
  
}
?>  





<?php



//print_r ($all_words);
$l=0;
foreach($arr as $all_words) {
$l=$l+1;

 $all_words=strtolower($all_words);

}

// echo'<br><br>Max:- '.max(array($li));
 
// echo'<br><br>Min:- '.min(array($li));


?>


